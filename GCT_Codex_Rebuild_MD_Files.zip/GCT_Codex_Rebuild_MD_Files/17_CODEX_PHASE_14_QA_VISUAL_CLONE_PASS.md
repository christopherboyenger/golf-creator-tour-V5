# Codex Phase 14 — QA Visual Clone Pass

## Goal

Perform the final 1:1 QA pass before production cutover.

## Copy/Paste Prompt For Codex

```md
Task:
Perform a full 1:1 QA pass against the current build spec and screenshots.

Check:
1. Every route renders.
2. Every nav button works.
3. No dead links.
4. Auth redirects work.
5. Middleware protection works.
6. Onboarding cannot finish without one social connected.
7. Profile tabs work.
8. Challenge join / submit / drop flows work.
9. Connect tabs work.
10. Sent match cancel works.
11. Messages page works.
12. Notifications panel works.
13. Hamburger drawer works.
14. Upgrade sheet works.
15. Empty states exist everywhere.
16. Mobile layout matches screenshots.
17. npm run build passes.
18. TypeScript passes.
19. No secrets are committed.

Return a checklist with pass/fail status and fix all failures.
```

## Acceptance Checklist

- [ ] All required routes render.
- [ ] No dead-end navigation.
- [ ] Auth and middleware pass.
- [ ] UI matches screenshots.
- [ ] Build passes.
- [ ] TypeScript passes.
- [ ] No secrets are committed.
- [ ] App is ready for staging QA.
