# GCT Codex Rebuild — Master Index

## Purpose

This folder contains Markdown handoff files for rebuilding the Golf Creator Tour app as a brand-new Codex-assisted build while preserving the current V4/V4.1 app as the source of truth.

The rebuild goal is simple:

```text
Same app.
Cleaner code.
No dead routes.
Better onboarding.
Real messages page.
Cleaner Supabase structure.
Same premium design.
```

## Golden Rule

Do not improve the product during the clone phase.

First create a 1:1 clone of the current build. Then improve it after the clone passes QA.

## Recommended Repo Name

```text
golf-creator-tour-v5
```

or

```text
gct-app-rebuild
```

## Recommended Repo Structure

```text
/golf-creator-tour-v5
  /app
  /components
  /hooks
  /lib
  /types
  /supabase
  /public
  /docs
  /docs/screenshots
  AGENTS.md
  README.md
  .env.example
```

## File Order

Use these files in order:

1. `01_AGENTS.md`
2. `02_ENVIRONMENT_VARIABLES.md`
3. `03_DATABASE_AND_SUPABASE_STRATEGY.md`
4. `04_CODEX_PHASE_01_REPO_SCAFFOLD.md`
5. `05_CODEX_PHASE_02_DESIGN_SYSTEM.md`
6. `06_CODEX_PHASE_03_SUPABASE_AUTH_FOUNDATION.md`
7. `07_CODEX_PHASE_04_AUTH_AND_ONBOARDING.md`
8. `08_CODEX_PHASE_05_DASHBOARD_SHELL.md`
9. `09_CODEX_PHASE_06_PROFILE_PAGE.md`
10. `10_CODEX_PHASE_07_COMPETE_PAGE.md`
11. `11_CODEX_PHASE_08_CREATE_CHALLENGES.md`
12. `12_CODEX_PHASE_09_CONNECT_MATCHES.md`
13. `13_CODEX_PHASE_10_SECONDARY_ROUTES.md`
14. `14_CODEX_PHASE_11_STRIPE_UPGRADE_FLOW.md`
15. `15_CODEX_PHASE_12_SOCIAL_CONNECTION_AND_POINTS.md`
16. `16_CODEX_PHASE_13_SUPABASE_SCHEMA_RLS.md`
17. `17_CODEX_PHASE_14_QA_VISUAL_CLONE_PASS.md`
18. `18_VERCEL_DEPLOYMENT_CHECKLIST.md`
19. `19_SCREENSHOT_REFERENCE_MAP.md`
20. `20_FINAL_PROMPT_SEQUENCE.md`

## Current Build Source of Truth

Use these files as source references inside the new repo:

```text
/docs/GCT_Current_Build.md
/docs/GCT_App_Flows.md
/docs/screenshots/
```

## Codex Workflow

```text
Codex builds feature branch
→ Codex opens PR
→ Run local checks
→ Review Vercel preview
→ Ask Codex to review/fix the PR
→ Merge
→ Move to next phase
```

## Local Commands After Every PR

```bash
npm install
npm run lint
npm run typecheck
npm run build
npm run dev
```

If `typecheck` is missing, add this script:

```json
{
  "scripts": {
    "typecheck": "tsc --noEmit"
  }
}
```
