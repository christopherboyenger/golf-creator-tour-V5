# Codex Phase 02 — Design System

## Goal

Build reusable GCT UI components before wiring data.

## Copy/Paste Prompt For Codex

```md
Read AGENTS.md and the screenshot references.

Task:
Build the reusable GCT design system components.

Create components for:
- AppShell
- BottomNav
- AppHeader
- SettingsDrawer
- NotificationPanel
- UpgradeMembershipSheet
- CreatorCard
- CreatorProfileSheet
- ChallengeCard
- ChallengeDetailSheet
- EmptyState
- LoadingSkeleton
- StatCard
- TourCard
- ModalSheet
- ConfirmationDialog
- Toast / success feedback pattern

Requirements:
1. Match the dark premium visual style from screenshots.
2. Mobile-first layout.
3. Reusable props with TypeScript types.
4. No backend logic yet.
5. Use mock data only where needed to render components.
6. Keep components organized and easy to wire later.

Do not redesign the product.
```

## Acceptance Checklist

- [ ] Core components exist.
- [ ] Components are typed.
- [ ] Components match screenshots.
- [ ] Components work on mobile.
- [ ] Components do not contain real backend logic.
- [ ] Reusable modal/sheet patterns exist.
