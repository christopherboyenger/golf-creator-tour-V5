# Codex Phase 10 — Secondary Routes

## Goal

Implement all referenced routes so the app has no dead ends.

## Copy/Paste Prompt For Codex

```md
Task:
Implement all referenced secondary routes so no navigation dead-ends exist.

Routes:
- /messages
- /home
- /how-to-compete
- /referrals
- /settings
- /admin
- /apply
- /brands
- /terms
- /privacy-policy
- /terms-of-service

Requirements:
1. /messages must render a valid mobile-first messages page using match_messages / matches data shape.
2. /home should be the GCO 2026 page.
3. /how-to-compete should explain the GCT loop:
   - Connect socials
   - Complete brand challenges
   - Play creator matches
   - Earn Tour Points
   - Climb leaderboard
   - Qualify for GCO
4. /referrals should match the referral screenshot.
5. /settings should match the settings screenshot.
6. /admin should use admin dashboard screenshots as reference.
7. Public funnel pages /apply and /brands should render simple public pages unless full website integration is handled separately.
8. No dead routes.
```

## Acceptance Checklist

- [ ] `/messages` exists.
- [ ] `/home` exists.
- [ ] `/how-to-compete` exists.
- [ ] `/referrals` exists.
- [ ] `/settings` exists.
- [ ] `/admin` exists.
- [ ] Legal/public pages exist.
- [ ] Header and drawer links all resolve.
