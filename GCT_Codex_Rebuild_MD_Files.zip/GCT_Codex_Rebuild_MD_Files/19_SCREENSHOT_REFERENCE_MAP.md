# Screenshot Reference Map

## Purpose

Use the uploaded screenshot folders as the visual reference source for the Codex rebuild.

Place the extracted screenshot folder here:

```text
/docs/screenshots/GCT APP Pages/
```

## Screenshot Groups

### Admin Dashboard

- `Analytics Page.png`
- `Applications Page.png`
- `Challenges Page.png`
- `Event Page.png`
- `Main Dashboard.png`
- `Matches Page.png`
- `Members Page.png`
- `Notifications Page.png`
- `Referrals Page.png`
- `Revenue Page.png`
- `Settings Page.png`
- `Submissions Page.png`

### Auth

- `Auth Landing Page.png`
- `onboarding_reset_password.png`
- `Password Set.png`
- `Sign in.png`
- `Sign Up.png`

### Compete (Leaderboard)

- `Leaderboard header.png`
- `Leaderboard page.png`

### Connect (Matches)

- `Browse Tab.png`
- `Matches Page Header.png`
- `Matches Tab.png`
- `Requests Tab.png`
- `Sent Tab.png`

### Create (Challenges)

- `Challenge Accepted Popup.png`
- `Challenge Submitted Popup.png`
- `Challenges Header.png`
- `challenges page.png`
- `Creator Challenge Card.png`
- `Submit Challenge Tab.png`
- `Submitted Tab.png`

### GCO 2026

- `GCO 2026 page.png`

### Hamburger Menu

- `Hamburger Menu.png`
- `Menu Log Out.png`

### Notifications & Messages

- `Delete Match Tab.png`
- `Messages & Settings.png`
- `Messeges Page.png`
- `Notifications Page.png`
- `Read Receipts Tab.png`
- `Report Tab.png`

### Profile

- `Badges Tab.png`
- `Location Edit Tab.png`
- `My Golf Bag Tab.png`
- `Overview Tab.png`
- `Profile Header.png`
- `Profile Tabs Bottom.png`
- `Profile Tabs.png`
- `Social Tab.png`
- `Submit Challenge Tab.png`

### Referral

- `referral page.png`

### Settings

- `settings page.png`

### Upgrade Membership Page

- `Upgrade Membership.png`


## How Codex Should Use Screenshots

Codex should use screenshots to match:

- Layout hierarchy
- Spacing
- Button styling
- Sheet/modal style
- Header treatment
- Bottom navigation treatment
- Empty state tone
- Card density
- Premium dark theme

Codex should not invent a new SaaS UI direction.

## Visual QA Rule

Every major route should be compared against its closest screenshot group before the PR is merged.
