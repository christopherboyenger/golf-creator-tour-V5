# Codex Phase 04 — Auth and Onboarding

## Goal

Implement the full invite-only auth, password activation, and onboarding experience.

## Copy/Paste Prompt For Codex

```md
Task:
Implement the GCT auth experience 1:1 from the current build spec and screenshots.

Routes:
- /auth
- /auth/reset-password
- /onboarding

Auth flow:
1. /auth shows splash/globe-style landing experience.
2. Enter Tour opens bottom auth card.
3. Login requires email and password.
4. Sign Up routes to external application funnel.
5. Successful login with must_reset_password routes to /auth/reset-password.
6. Reset password requires:
   - minimum 8 characters
   - password confirmation match
   - cannot start with GCT-
7. Successful password reset routes to /onboarding.
8. Onboarding steps:
   - Welcome [First Name], let's get you started.
   - Allow Location.
   - Allow Push Notifications.
   - Connect Social Media.
   - Require at least one social platform to continue.
   - Celebration animation with points.
   - Route to /profile.

Use existing design system components.
Preserve dark premium styling.
```

## Acceptance Checklist

- [ ] `/auth` renders landing/splash state.
- [ ] Login validation exists.
- [ ] Sign Up routes externally.
- [ ] Password reset blocks member-number passwords.
- [ ] Password confirmation works.
- [ ] Onboarding has welcome, location, push, social, celebration, profile route.
- [ ] User cannot finish onboarding without one social platform connected.
