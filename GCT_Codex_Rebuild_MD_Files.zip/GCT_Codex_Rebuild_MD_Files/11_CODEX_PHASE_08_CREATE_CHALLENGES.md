# Codex Phase 08 — Create Challenges

## Goal

Build the Brand Challenges hub and admin challenge management.

## Copy/Paste Prompt For Codex

```md
Task:
Build the /create Brand Challenges page.

Required filters:
- All
- Standard
- Premium
- Elite
- GCT
- Submitted

Required challenge card actions:
- Tap challenge card opens Challenge Detail Sheet.
- Join Challenge.
- Submit Challenge.
- Drop Challenge.
- Upgrade CTA for gated tiers.
- Submitted state.
- Coming Soon / closed state.

Challenge Detail Sheet must show:
- Tier badge
- Points
- Brand logo/name
- Description
- Participants
- Spots
- Deadline
- Requirements checklist
- CTA area

Admin users:
- Show Create Challenge
- Show Edit Challenge
- Admin Challenge Form with:
  - Brand logo
  - Title
  - Brand
  - Description
  - Tier
  - Points
  - Max slots
  - Duration
  - Status
  - Brand color
  - Requirements

Do not redesign.
```

## Acceptance Checklist

- [ ] Challenge filters render.
- [ ] Challenge cards render.
- [ ] Detail sheet opens.
- [ ] Join flow exists.
- [ ] Submit flow exists.
- [ ] Drop flow exists.
- [ ] Upgrade CTA exists for locked tiers.
- [ ] Admin challenge form exists.
