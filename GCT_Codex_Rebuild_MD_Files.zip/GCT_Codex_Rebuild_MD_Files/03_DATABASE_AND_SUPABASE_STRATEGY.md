# Database and Supabase Strategy

## Recommendation

Use a new staging Supabase project for the Codex rebuild.

Do not point the brand-new app at the live production Supabase database while Codex is still building features.

## Why

The rebuild will involve:

- New middleware
- New auth helpers
- New database queries
- New API routes
- New admin flows
- New migrations
- New Stripe webhook tests
- New social sync logic

That is too much risk for live creator/member data.

## Recommended Setup

```text
Production Supabase = current live app
Staging Supabase = Codex rebuild/testing app
```

## Required Tables

```text
creators
social_connections
challenges
challenge_participations
matches
match_messages
notifications
creator_sponsors
golf_bag
referrals
applications
subscriptions
```

## Required Storage Buckets

```text
avatars
challenge-submissions
match-scorecards
brand-logos
```

## Required Supabase Areas

### Auth

Used for:

- Sign in
- Session management
- Temporary password/member number flow
- Password activation
- Logout
- Admin role checks

### Creators Table

Used for:

- Profile data
- Creator status
- Membership tier
- Role/admin permissions
- Location
- Onboarding completion
- Must reset password
- Tour member number
- Points and leaderboard rank

### Social Connections

Used for:

- Connected platform
- Handle
- Profile URL
- Followers
- Last synced timestamp
- Points awarded

### Challenges

Used for:

- Brand challenge cards
- Challenge status
- Points
- Requirements
- Max slots
- Tier gating

### Matches

Used for:

- Creator match requests
- Accepted matches
- Sent requests
- Match score submissions
- Match status

### Notifications

Used for:

- Header notification badge
- Full-screen notifications panel
- Notification routing

## Migration Strategy

1. Create migrations in `/supabase/migrations`.
2. Seed only fake test data for local/staging.
3. Enable RLS before connecting real users.
4. Keep service role access limited to server-only API routes.
5. Add indexes for leaderboard, creator status, challenges, matches, and notifications.

## Cutover Strategy

```text
Build against staging Supabase
→ QA all user flows
→ Export/mirror required schema
→ Connect production Supabase in Vercel
→ Smoke test admin + creator accounts
→ Swap domain only after approval
```
