# Codex Phase 07 — Compete Page

## Goal

Build the leaderboard and competitive ranking hub.

## Copy/Paste Prompt For Codex

```md
Task:
Build the /compete leaderboard page.

Required sections:
- Hero stats
- Current user rank
- Exempt podium
- Activity feed
- Search input
- Country filter
- Gender filter
- Leaderboard list
- Sticky rank pill
- Full leaderboard sheet
- Creator Profile Sheet on creator tap

Ranking behavior:
- Exempt creators separated from standard leaderboard.
- Tied ranks display as T#.
- Zero-point creators show rank as —.
- Current user row highlighted.
- Rank movement displays up/down movement.

Add loading, error, and empty states.
Match screenshots closely.
```

## Acceptance Checklist

- [ ] Leaderboard renders.
- [ ] Search works.
- [ ] Filters work.
- [ ] Podium section exists.
- [ ] Creator Profile Sheet opens.
- [ ] Tied ranks display as `T#`.
- [ ] Zero-point creators show `—`.
- [ ] Current user row is highlighted.
