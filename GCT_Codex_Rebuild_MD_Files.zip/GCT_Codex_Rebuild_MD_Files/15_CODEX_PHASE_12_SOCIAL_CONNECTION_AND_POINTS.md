# Codex Phase 12 — Social Connection and Points

## Goal

Implement social connection, follower sync, and point celebration flows.

## Copy/Paste Prompt For Codex

```md
Task:
Implement social connection and sync flows.

API routes:
- /api/social/connect-handle
- /api/social/scrape-sync
- /api/social/application-handles

Requirements:
1. Connect Instagram, TikTok, YouTube.
2. Verify platform handle.
3. Save platform, handle, follower count, and awarded points.
4. Onboarding requires at least one platform connected.
5. Profile Social tab allows syncing.
6. Sync success shows platforms updated and points awarded.
7. Sync failure shows error toast.
8. Add celebration animation after points are awarded.

Use placeholders where external API credentials are missing.
Do not fake successful production sync silently.
```

## Acceptance Checklist

- [ ] Connect handle route exists.
- [ ] Scrape sync route exists.
- [ ] Application handles route exists.
- [ ] Instagram/TikTok/YouTube UI exists.
- [ ] Onboarding social requirement is enforced.
- [ ] Points celebration exists.
- [ ] Failed sync shows error.
