# Vercel Deployment Checklist

## Goal

Deploy the rebuild safely without disrupting the current live app.

## Recommended Setup

```text
Current production app:
golfcreatortour.app

New rebuild staging app:
staging.golfcreatortour.app
```

## Vercel Project Setup

1. Create a new Vercel project.
2. Connect it to the new GitHub repo.
3. Set framework to Next.js.
4. Add environment variables from `.env.example`.
5. Connect staging Supabase first.
6. Deploy preview branch.
7. QA every app route.

## Required Environment Variables

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
NEXT_PUBLIC_APP_URL=
NEXT_PUBLIC_SITE_URL=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
STRIPE_PREMIUM_MONTHLY_PRICE_ID=
STRIPE_PREMIUM_ANNUAL_PRICE_ID=
STRIPE_ELITE_MONTHLY_PRICE_ID=
STRIPE_ELITE_ANNUAL_PRICE_ID=
SCRAPE_CREATORS_API_KEY=
```

## Pre-Cutover Checklist

- [ ] Auth works on staging.
- [ ] Password reset activation works.
- [ ] Onboarding works.
- [ ] Profile renders real data.
- [ ] Compete leaderboard renders real data.
- [ ] Create challenges render real data.
- [ ] Connect matches render real data.
- [ ] Messages render real data.
- [ ] Notifications render real data.
- [ ] Admin dashboard works.
- [ ] Stripe checkout uses correct price IDs.
- [ ] Stripe webhooks are registered.
- [ ] Supabase RLS policies are tested.
- [ ] No console errors on mobile.
- [ ] No dead routes.
- [ ] No leaked secrets.
- [ ] `npm run build` passes.

## Production Cutover

Only after staging passes:

```text
Swap domain
→ Smoke test login
→ Test creator account
→ Test admin account
→ Test Stripe checkout in live mode
→ Monitor logs
```

## Rollback Plan

Keep the current production app active until the new build is confirmed stable.

If anything breaks:

```text
Repoint domain back to old production Vercel project
→ Investigate staging
→ Patch rebuild
→ Try cutover again
```
