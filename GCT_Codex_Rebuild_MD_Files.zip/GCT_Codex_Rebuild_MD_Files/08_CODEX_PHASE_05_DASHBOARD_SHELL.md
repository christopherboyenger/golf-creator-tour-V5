# Codex Phase 05 — Dashboard Shell

## Goal

Implement the authenticated app shell, header, hamburger drawer, and bottom navigation.

## Copy/Paste Prompt For Codex

```md
Task:
Implement the authenticated dashboard shell and core navigation.

Routes:
- /profile
- /compete
- /create
- /connect

Requirements:
1. Use the fixed bottom nav.
2. Use the shared app header.
3. Header actions:
   - Notifications opens full-screen panel.
   - Messages routes to /messages.
   - Hamburger opens settings drawer.
4. Hamburger menu order:
   - Upgrade Membership
   - GCO 2026
   - How to Compete
   - Referral Program
   - Settings
   - Admin Dashboard for admins only
   - Log Out
5. Add global loading skeleton.
6. Add global achievement celebration overlay placeholder.
7. Use mock data where needed.
8. Keep layouts visually matched to screenshots.
```

## Acceptance Checklist

- [ ] Header exists on dashboard pages.
- [ ] Bottom nav exists and routes correctly.
- [ ] Notifications panel opens/closes.
- [ ] Messages button routes to `/messages`.
- [ ] Hamburger drawer menu order is correct.
- [ ] Admin item only shows for admins.
- [ ] Logout confirmation exists.
