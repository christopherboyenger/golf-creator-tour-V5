# Codex Phase 11 — Stripe Upgrade Flow

## Goal

Implement the upgrade membership sheet and Stripe checkout flow.

## Copy/Paste Prompt For Codex

```md
Task:
Implement the Upgrade Membership Sheet and Stripe checkout flow.

Plans:
- Standard: Free
- Premium: $20/month or $100/year
- Elite: $40/month or $200/year
- Founding Member: Limited 1 of 100 Elite Annual positioning

Requirements:
1. Monthly / Annual billing toggle.
2. Current Plan disabled state.
3. Upgrade buttons call /api/checkout.
4. /api/checkout creates Stripe Checkout session.
5. /api/webhooks/stripe processes subscription events.
6. Show clear errors for missing Stripe config.
7. If native iOS / Capacitor is detected, do not show Stripe checkout button. Show iOS subscription instruction text instead.
8. Use environment variables from .env.example.
```

## Acceptance Checklist

- [ ] Upgrade sheet renders.
- [ ] Billing toggle works.
- [ ] Current plan state works.
- [ ] `/api/checkout` exists.
- [ ] `/api/webhooks/stripe` exists.
- [ ] Missing config errors are clear.
- [ ] No Stripe secrets client-side.
