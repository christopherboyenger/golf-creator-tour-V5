# Codex Phase 06 — Profile Page

## Goal

Build the creator home dashboard.

## Copy/Paste Prompt For Codex

```md
Task:
Build the /profile page 1:1 from the current build spec.

Profile tabs:
- Overview
- Social
- Badges

Overview must include:
- Profile header
- Avatar flow placeholder
- Location edit flow
- Tour Card display
- Creator Snapshot
- Active Challenges
- Accepted Matches
- Sponsors
- Golf Bag

Social tab must include:
- Instagram connection
- TikTok connection
- YouTube connection
- Sync socials action
- Points celebration on success

Badges tab:
- Show badge grid.
- Keep badges read-only for now unless existing code/spec defines detail behavior.

Required empty states:
- No active challenges
- No sponsors
- No golf bag
- No matches
- No social accounts connected
- No badges yet

Use Supabase query placeholders if schema is not fully available.
```

## Acceptance Checklist

- [ ] Overview tab renders.
- [ ] Social tab renders.
- [ ] Badges tab renders.
- [ ] Location edit UI exists.
- [ ] Sponsor section exists.
- [ ] Golf bag section exists.
- [ ] Empty states exist.
- [ ] Social connection UI exists.
