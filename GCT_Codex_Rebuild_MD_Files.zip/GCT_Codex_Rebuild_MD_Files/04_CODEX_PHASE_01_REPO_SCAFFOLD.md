# Codex Phase 01 — Repo Scaffold

## Goal

Create the base app scaffold only.

## Copy/Paste Prompt For Codex

```md
You are rebuilding the Golf Creator Tour app as a brand-new Next.js 15 / React 19 app.

Read:
- /docs/GCT_Current_Build.md
- /docs/screenshots
- AGENTS.md

Task:
Create the base app scaffold only.

Requirements:
1. Set up Next.js app router with TypeScript.
2. Add Tailwind and global dark premium GCT theme styles.
3. Create the route folders for all required routes listed in AGENTS.md.
4. Add a shared mobile-first dashboard shell.
5. Add placeholder pages only. Do not implement data logic yet.
6. Add bottom nav with Profile, Compete, Create, Connect.
7. Add centered header logo area, notifications button, messages button, hamburger button.
8. Add .env.example if missing.
9. Add README setup instructions.

Do not redesign.
Do not add extra routes.
Do not connect Supabase yet.

Return a PR with the scaffold.
```

## Acceptance Checklist

- [ ] App runs locally.
- [ ] Required routes exist.
- [ ] Bottom nav exists.
- [ ] Header exists.
- [ ] Dark premium base theme exists.
- [ ] No Supabase dependency yet.
- [ ] `npm run build` passes.
