# Codex Phase 03 — Supabase Auth Foundation

## Goal

Set up Supabase clients, middleware, auth helpers, and route protection.

## Copy/Paste Prompt For Codex

```md
Task:
Set up Supabase foundation for the GCT app.

Requirements:
1. Create browser and server Supabase clients.
2. Add typed auth helpers.
3. Add middleware matching the current build spec.
4. Implement route protection:
   - Logged-out users visiting protected routes redirect to /auth.
   - Logged-in users with incomplete onboarding redirect to /onboarding.
   - Users who must reset password redirect to /auth/reset-password.
   - Non-admin users visiting /admin redirect to /profile.
5. Public routes must include:
   - /auth
   - /api/auth/callback
   - /onboarding
   - /terms
   - /privacy-policy
   - /terms-of-service
   - /apply
   - /brands
6. Do not implement full pages yet.
7. Add clear TODOs where exact table names or columns need verification.

Use AGENTS.md and /docs/GCT_Current_Build.md as source of truth.
```

## Acceptance Checklist

- [ ] Browser Supabase client exists.
- [ ] Server Supabase client exists.
- [ ] Middleware exists.
- [ ] Public routes are allowed.
- [ ] Protected routes redirect logged-out users.
- [ ] Incomplete onboarding redirects correctly.
- [ ] Admin routes are protected.
- [ ] Service role key is never client-side.
