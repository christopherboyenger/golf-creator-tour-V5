# Codex Phase 09 — Connect Matches

## Goal

Build creator discovery, match requests, accepted matches, and sent request management.

## Copy/Paste Prompt For Codex

```md
Task:
Build the /connect page.

Tabs:
- Browse
- Requests
- Matches
- Sent

Browse:
- Country filter
- Region/state filter
- Sort by name, followers, handicap, rank
- Creator cards
- Creator Profile Sheet
- Challenge creator flow

Requests:
- Accept request
- Decline request

Matches:
- Chat / Message
- Submit Score
- Upload scorecard
- Optional video link
- Submit match score

Sent:
- Display outgoing requests
- Add Cancel Request flow:
  - Tap pending request
  - Show confirmation
  - Cancel request in Supabase
  - Refresh sent requests
  - Show success/error toast

Add empty states for all tabs.
```

## Acceptance Checklist

- [ ] Browse tab renders.
- [ ] Requests tab renders.
- [ ] Matches tab renders.
- [ ] Sent tab renders.
- [ ] Creator profile sheet opens.
- [ ] Challenge creator flow exists.
- [ ] Accept/decline requests exist.
- [ ] Submit score flow exists.
- [ ] Cancel sent request flow exists.
