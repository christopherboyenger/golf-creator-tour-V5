# Codex Phase 13 — Supabase Schema and RLS

## Goal

Create portable database documentation, migrations, RLS policies, and indexes.

## Copy/Paste Prompt For Codex

```md
Task:
Create Supabase schema documentation and migration files for the rebuilt GCT app.

Requirements:
1. Inspect current data usage across the app.
2. Create /supabase/migrations for required tables.
3. Add /docs/DATABASE_SCHEMA.md.
4. Include tables:
   - creators
   - social_connections
   - challenges
   - challenge_participations
   - matches
   - match_messages
   - notifications
   - creator_sponsors
   - golf_bag
   - referrals
   - applications
   - subscriptions
5. Add recommended RLS policies.
6. Do not expose service role key client-side.
7. Add indexes for leaderboard, creator status, challenge participation, match requests, and notifications.
8. Add seed data for local testing only.
```

## Acceptance Checklist

- [ ] Migrations exist.
- [ ] Database schema doc exists.
- [ ] RLS policies exist.
- [ ] Indexes exist.
- [ ] Seed data is local/staging only.
- [ ] Service role key is protected.
