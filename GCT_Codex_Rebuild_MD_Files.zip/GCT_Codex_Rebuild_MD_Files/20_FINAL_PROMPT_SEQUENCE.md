# Final Codex Prompt Sequence

## Use This Exact Order

Paste these prompts into Codex one phase at a time.

Do not paste all phases at once.

## Phase Order

```text
Phase 01 — Repo Scaffold
Phase 02 — Design System
Phase 03 — Supabase Auth Foundation
Phase 04 — Auth and Onboarding
Phase 05 — Dashboard Shell
Phase 06 — Profile Page
Phase 07 — Compete Page
Phase 08 — Create Challenges
Phase 09 — Connect Matches
Phase 10 — Secondary Routes
Phase 11 — Stripe Upgrade Flow
Phase 12 — Social Connection and Points
Phase 13 — Supabase Schema and RLS
Phase 14 — QA Visual Clone Pass
```

## Branch Naming

```text
phase-01-repo-scaffold
phase-02-design-system
phase-03-supabase-auth-foundation
phase-04-auth-onboarding
phase-05-dashboard-shell
phase-06-profile-page
phase-07-compete-page
phase-08-create-challenges
phase-09-connect-matches
phase-10-secondary-routes
phase-11-stripe-upgrade-flow
phase-12-social-connection-points
phase-13-supabase-schema-rls
phase-14-qa-visual-clone-pass
```

## PR Review Prompt

Use this after every Codex PR:

```md
@codex review this PR against AGENTS.md, /docs/GCT_Current_Build.md, and the relevant screenshot folder.

Focus on:
- 1:1 visual accuracy
- missing routes
- broken navigation
- auth/middleware regressions
- mobile layout issues
- missing loading/error/empty states
- TypeScript errors
- security mistakes
- secrets accidentally exposed

Return clear pass/fail notes and fix any issues found.
```

## Final Rule

If Codex tries to redesign the app, stop the PR and tell it:

```md
Do not redesign. Revert visual drift and match the current GCT screenshots 1:1.
```
