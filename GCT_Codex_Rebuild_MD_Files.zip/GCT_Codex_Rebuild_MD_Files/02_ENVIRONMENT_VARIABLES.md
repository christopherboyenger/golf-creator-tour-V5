# Environment Variables

Create a `.env.example` file in the repo root with the following variables.

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

NEXT_PUBLIC_APP_URL=
NEXT_PUBLIC_SITE_URL=

STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=

STRIPE_PREMIUM_MONTHLY_PRICE_ID=
STRIPE_PREMIUM_ANNUAL_PRICE_ID=
STRIPE_ELITE_MONTHLY_PRICE_ID=
STRIPE_ELITE_ANNUAL_PRICE_ID=

SCRAPE_CREATORS_API_KEY=
```

## Rules

- Never commit `.env.local`.
- Never expose `SUPABASE_SERVICE_ROLE_KEY` client-side.
- Stripe secret keys only run server-side.
- Add missing variables only if a real feature requires them.
- Use Vercel environment variables for staging and production.

## Recommended Environments

```text
Local Development → .env.local
Staging → Vercel Preview / staging.golfcreatortour.app
Production → Vercel Production / golfcreatortour.app
```

## Recommended Supabase Split

```text
Current production app → current Supabase project
New Codex rebuild → new staging Supabase project
```

Do not connect the rebuild to production data until QA is complete.
