# Vercel Setup — Existing Supabase Backend

## Recommended Deployment Setup

Use a new Vercel project for the rebuild.

Example:

```text
staging.golfcreatortour.app
```

or

```text
gct-rebuild.vercel.app
```

## Environment Variables In Vercel

Add the existing Supabase backend credentials:

```env
NEXT_PUBLIC_SUPABASE_URL=https://qvuqjpcxnnikbigixupb.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

Also add the existing Stripe/social variables:

```env
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=

STRIPE_PREMIUM_MONTHLY_PRICE_ID=
STRIPE_PREMIUM_ANNUAL_PRICE_ID=
STRIPE_ELITE_MONTHLY_PRICE_ID=
STRIPE_ELITE_ANNUAL_PRICE_ID=

SCRAPE_CREATORS_API_KEY=
```

## Important

Use Preview Deployments carefully.

Because this rebuild points to the same backend, preview deployments can still affect real data if mutation code is active.

Recommended safety phase:

```text
Phase 1: Read-only data wiring
Phase 2: Auth/session testing
Phase 3: Controlled mutation testing with test creator accounts
Phase 4: Stripe test mode only
Phase 5: Production domain swap
```

## Test Creator Accounts

Create or identify test creator accounts in the existing Supabase project.

Use test accounts for:

- password activation
- onboarding
- location permission
- social connection
- challenge join/drop/submit
- match request
- message flow
- referral flow
- membership upgrade
