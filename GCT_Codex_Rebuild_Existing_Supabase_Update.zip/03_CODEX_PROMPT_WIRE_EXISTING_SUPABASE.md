# Codex Prompt — Wire App To Existing Supabase

Use this after the backend discovery pass.

```md
Task:
Wire the new GCT rebuild to the existing Supabase backend.

Existing Supabase project:
qvuqjpcxnnikbigixupb

Requirements:
1. Use NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY for browser-safe client access.
2. Use SUPABASE_SERVICE_ROLE_KEY only inside server-only code paths:
   - API routes
   - server actions
   - admin operations
   - webhook handlers
3. Create Supabase clients:
   - /lib/supabase/client.ts
   - /lib/supabase/server.ts
   - /lib/supabase/admin.ts
4. Use @supabase/ssr for server-side auth session handling.
5. Preserve invite-only auth flow:
   - no public app signup
   - login with email + temporary member number/password
   - force password reset when must_reset_password is true
   - force onboarding when onboarding_completed is false
6. Use existing creator profile fields and table names.
7. Use existing challenge/match/notification tables.
8. If an expected field does not exist, document it in /docs/BACKEND_GAPS.md instead of creating a migration immediately.
9. Add safe error states for missing tables, missing columns, or unavailable policies.
10. Do not alter production data during wiring.

Deliverables:
- Supabase client files
- Auth helpers
- Middleware
- Backend gap report
- TypeScript types matching discovered schema as closely as possible
```
