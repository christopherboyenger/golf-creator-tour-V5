# Testing Checklist — New App With Existing Live Backend

## Before Testing

- Confirm `.env.local` points to `https://qvuqjpcxnnikbigixupb.supabase.co`
- Confirm service role key is server-only.
- Confirm no destructive migrations are pending.
- Confirm Stripe is in test mode during rebuild testing.
- Confirm test creator accounts are available.

## Auth Testing

- Logged-out user visiting `/profile` redirects to `/auth`.
- Active user logs in successfully.
- User with `must_reset_password = true` redirects to `/auth/reset-password`.
- Password reset blocks member-number-style passwords.
- User with incomplete onboarding redirects to `/onboarding`.
- Active onboarded user redirects to `/profile`.

## Onboarding Testing

- Welcome step renders first name.
- Location permission works.
- Push notification request renders.
- Social connection step requires at least one platform.
- Points celebration renders after social connection.
- Completion updates existing backend correctly.

## Core App Testing

- Profile reads real creator data.
- Social tab reads real social connections.
- Compete reads real leaderboard data.
- Create reads real challenges.
- Connect reads real creators/matches.
- Notifications read real notifications.
- Messages read real match messages.
- Settings reads/writes safe profile preferences.
- Referrals read real referral data where available.

## Mutation Testing

Use only test creator accounts.

Test:

- Update profile location.
- Add sponsor.
- Add golf bag item.
- Join challenge.
- Drop challenge.
- Submit challenge.
- Send match request.
- Cancel sent match request.
- Accept/decline match request.
- Submit match score.
- Send match message.

## Final Safety Pass

- No service role key appears in browser bundle.
- No admin routes accessible by non-admins.
- No public signup inside app.
- No dead routes.
- No production data changed by test flows except test accounts.
