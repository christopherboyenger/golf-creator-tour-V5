# Codex Prompt — Backend Discovery For Existing Supabase

Paste this into Codex before wiring data logic.

```md
You are rebuilding the Golf Creator Tour app in a new repo, but you must use the existing Supabase backend.

Existing Supabase project ref:
qvuqjpcxnnikbigixupb

Existing Supabase URL:
https://qvuqjpcxnnikbigixupb.supabase.co

Read:
- AGENTS.md
- /docs/GCT_Current_Build.md
- /docs/GCT_App_Flows.md
- /docs/screenshots

Task:
Perform a backend discovery and integration planning pass.

Requirements:
1. Do not create a new Supabase project.
2. Do not create destructive migrations.
3. Do not rename existing tables.
4. Do not change existing RLS policies.
5. Identify the existing backend assumptions needed by the app:
   - auth user to creator profile linking
   - creator status
   - must_reset_password
   - onboarding_completed
   - creator role/admin role
   - social connections
   - challenges
   - challenge participations
   - matches
   - match messages
   - notifications
   - creator sponsors
   - golf bag
   - referrals
   - subscriptions
   - storage buckets
6. Create a file:
   /docs/BACKEND_DISCOVERY_CHECKLIST.md

The checklist should include:
- Required tables
- Required columns
- Required policies
- Required storage buckets
- Required API routes
- Unknowns that need dashboard verification

Important:
If schema details are unknown, add TODO comments and type-safe fallbacks.
Do not guess destructive database changes.
Do not expose service role key client-side.
```
