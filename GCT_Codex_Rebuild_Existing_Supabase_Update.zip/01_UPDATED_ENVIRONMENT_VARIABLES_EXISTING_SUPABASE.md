# Environment Variables — Existing GCT Supabase Backend

## Required Supabase Variables

Use the existing Supabase project:

```text
qvuqjpcxnnikbigixupb
```

The Supabase project URL should look like:

```env
NEXT_PUBLIC_SUPABASE_URL=https://qvuqjpcxnnikbigixupb.supabase.co
```

Required variables:

```env
NEXT_PUBLIC_SUPABASE_URL=https://qvuqjpcxnnikbigixupb.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=

SUPABASE_SERVICE_ROLE_KEY=

NEXT_PUBLIC_APP_URL=
NEXT_PUBLIC_SITE_URL=
```

## Stripe Variables

Use the same Stripe backend/config currently used by the live GCT app.

```env
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=

STRIPE_PREMIUM_MONTHLY_PRICE_ID=
STRIPE_PREMIUM_ANNUAL_PRICE_ID=
STRIPE_ELITE_MONTHLY_PRICE_ID=
STRIPE_ELITE_ANNUAL_PRICE_ID=
```

## Social Sync Variables

Use the same social backend/API provider currently used by the live app.

```env
SCRAPE_CREATORS_API_KEY=
```

## Critical Security Rule

Only these variables are safe for browser/client use:

```env
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
NEXT_PUBLIC_APP_URL
NEXT_PUBLIC_SITE_URL
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
```

These must never be exposed in frontend/client bundles:

```env
SUPABASE_SERVICE_ROLE_KEY
STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET
SCRAPE_CREATORS_API_KEY
```

## Codex Instruction

Do not invent new variable names unless absolutely required.

Use the existing backend variable naming conventions wherever possible.
