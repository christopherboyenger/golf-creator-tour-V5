# Existing Supabase Guardrails

## Golden Rule

The existing Supabase project is the production backend source of truth.

Codex must adapt the new frontend to the current backend, not the other way around.

## Allowed

Codex may:

- Read from existing tables.
- Insert normal app records through safe app flows.
- Update records through existing app flows.
- Use existing storage buckets.
- Create non-destructive documentation.
- Create local TypeScript types.
- Add non-destructive migrations only after explicit approval.
- Add new API routes in the Next.js app that use existing Supabase data.

## Not Allowed Without Explicit Approval

Codex must not:

- Drop tables.
- Drop columns.
- Rename tables.
- Rename columns.
- Disable RLS.
- Loosen RLS policies.
- Delete production data.
- Recreate auth users.
- Change existing storage bucket permissions.
- Rotate keys.
- Modify Stripe webhook behavior without confirmation.
- Change live creator statuses.
- Change live membership/subscription records.

## Backend Change Protocol

If a backend change is needed, Codex must create:

```text
/docs/BACKEND_CHANGE_REQUEST.md
```

With:

- Problem
- Existing behavior
- Proposed change
- Tables affected
- RLS impact
- Risk level
- Rollback plan
- SQL migration preview

No backend migration should be applied automatically.
