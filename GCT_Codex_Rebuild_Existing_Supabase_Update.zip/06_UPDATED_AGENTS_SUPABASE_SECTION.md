# Updated AGENTS.md Supabase Section

Replace the previous Supabase/staging guidance in AGENTS.md with this section.

```md
## Supabase Backend Rule

This rebuild uses the existing Golf Creator Tour Supabase backend.

Existing Supabase project ref:

qvuqjpcxnnikbigixupb

Existing Supabase URL:

https://qvuqjpcxnnikbigixupb.supabase.co

Do not create a new Supabase project unless explicitly instructed.

The new frontend must be wired to the existing backend and must preserve the current production data model.

## Backend Safety Rules

- Do not drop tables.
- Do not drop columns.
- Do not rename tables.
- Do not rename columns.
- Do not disable RLS.
- Do not loosen RLS policies.
- Do not delete production data.
- Do not expose service role keys in client code.
- Do not hardcode secrets.
- Do not invent schema if existing schema can be discovered.

## Backend Discovery First

Before wiring feature logic, inspect or document the expected existing backend schema.

Create:

/docs/BACKEND_DISCOVERY_CHECKLIST.md

If a schema gap is found, create:

/docs/BACKEND_GAPS.md

If a backend change is truly required, create:

/docs/BACKEND_CHANGE_REQUEST.md

Do not apply destructive migrations automatically.

## Data Access

Use:

- Browser Supabase client for normal authenticated creator actions.
- Server Supabase client for SSR/session-aware data access.
- Admin Supabase client with service role only in server-only code paths.

## Auth Model

Preserve invite-only app access:

External website application
→ Admin approval
→ Supabase Auth user exists
→ Creator logs in
→ Password reset activation if required
→ Onboarding
→ Dashboard
```
