# GCT Codex Rebuild — Use Existing Supabase Backend

## Decision

The new Codex rebuild should use the existing Golf Creator Tour Supabase backend.

Existing Supabase project:

```text
https://supabase.com/dashboard/project/qvuqjpcxnnikbigixupb
```

Project ref:

```text
qvuqjpcxnnikbigixupb
```

## Updated Architecture

```text
New GitHub repo / Codex rebuild
        ↓
New Next.js app codebase
        ↓
Same existing Supabase project
        ↓
Same Auth users, creators, challenges, matches, notifications, subscriptions, and storage
```

## What Changes From The Original Plan

Original plan recommended a staging Supabase project.

This update overrides that.

Use:

```text
Same Supabase project.
Same database.
Same backend.
Same auth system.
Same storage buckets.
Same API assumptions.
```

## What Codex Must Not Do

Codex must not:

- Create a new Supabase project.
- Rename existing tables.
- Delete existing tables.
- Rewrite RLS policies without explicit approval.
- Generate destructive migrations.
- Change production data.
- Assume new schema names.
- Replace the backend architecture.
- Hardcode Supabase credentials.
- Expose the service role key in client code.

## What Codex Should Do First

Codex should first perform a backend discovery pass.

It should identify:

- Existing table names
- Existing column names
- Existing relationships
- Existing auth profile linking logic
- Existing storage buckets
- Existing API routes
- Existing RPC functions, if any
- Existing RLS-sensitive operations

Then it should wire the new frontend to match the current backend exactly.

## Recommended Build Rule

Before creating new schema, Codex must prove the current backend cannot support the required feature.

Default posture:

```text
Use what already exists.
Adapt the frontend to the backend.
Do not adapt the backend to Codex.
```
